//
//  ViewController.swift
//  pizza
//
//  Created by ritesh Chowdary on 3/4/20.
//  Copyright © 2020 Ritesh Chowdary. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var tops = 0

    @IBOutlet weak var msg: UILabel!
    @IBOutlet weak var amount: UITextField!
    @IBOutlet weak var qty: UITextField!
    @IBOutlet weak var peprd: UIButton!
    @IBOutlet weak var olives: UIButton!
    @IBOutlet weak var cheese: UIButton!
    @IBOutlet weak var bcn: UIButton!
    @IBOutlet weak var susg: UIButton!
    @IBOutlet weak var onion: UIButton!
    @IBOutlet weak var mshr: UIButton!
    @IBOutlet weak var pep: UIButton!
    @IBOutlet weak var large: UIButton!
    @IBOutlet weak var medium: UIButton!
    @IBOutlet weak var small: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func smAction(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
        }
        else {
            sender.isSelected = true
            medium.isSelected = false
            large.isSelected = false
        }
        
    }
    
    @IBAction func mdAction(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
        }
        else {
            sender.isSelected = true
            small.isSelected = false
            large.isSelected = false
        }
    }
    @IBAction func lgAction(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
        }
        else {
            sender.isSelected = true
            medium.isSelected = false
            small.isSelected = false
        }
    }
    @IBAction func msh(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
            tops = tops - 1
        }
        else {
            sender.isSelected = true
            tops = tops + 1
        }
    }
    @IBAction func pepAction(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
            tops = tops - 1
        }
        else {
            sender.isSelected = true
            tops = tops + 1
        }
        
    }
    @IBAction func onAction(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
            tops = tops - 1
        }
        else {
            sender.isSelected = true
            tops = tops + 1
        }
        
    }
    @IBAction func ssgAction(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
            tops = tops - 1
        }
        else {
            sender.isSelected = true
            tops = tops + 1
        }
        
    }
    @IBAction func bcnAction(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
            tops = tops - 1
        }
        else {
            sender.isSelected = true
            tops = tops + 1
        }
        
    }
    @IBAction func chAction(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
            tops = tops - 1
        }
        else {
            sender.isSelected = true
            tops = tops + 1
        }
        
    }
    @IBAction func oliveAction(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
            tops = tops - 1
        }
        else {
            sender.isSelected = true
            tops = tops + 1
        }
        
    }
    @IBAction func pprAction(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
            tops = tops - 1
        }
        else {
            sender.isSelected = true
            tops = tops + 1
        }
        
    }
    
    @IBAction func orderAction(_ sender: Any) {
        var price = 0.0
        
        if small.isSelected {
            price = price + 8.99
        }
        else if medium.isSelected{
            price = price + 12.99
        }
        else if large.isSelected{
            price = price + 14.99
        }
        if let q = qty.text, !q.isEmpty{
            msg.text = ""
            price = price + 2 * (Double(tops) - 2)
            let qt = (Double(q))!
            price = price * Double(qt) * 1.13
            amount.text = String(format: "%.2f",price)
            msg.text = "Ordered Successfully!!"
        }else{
            msg.text = "Please enter the quantity"
        }
    }
}

